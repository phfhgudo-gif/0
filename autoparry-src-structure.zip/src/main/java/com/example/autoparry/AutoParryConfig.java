package com.example.autoparry;

/** Runtime settings used by the client handlers. */
public final class AutoParryConfig {
    private AutoParryConfig() {}

    public static boolean autoParryEnabled = true;
    public static boolean autoDodgeEnabled = false;
    public static double detectionRange = 4.0D;
    public static int actionCooldownTicks = 8;
}
