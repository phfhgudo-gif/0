package com.example.autoparry.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;

public final class AutoParryKeys {
    public static final KeyMapping TOGGLE_PARRY = new KeyMapping(
            "key.autoparry.toggle_parry", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.autoparry");
    public static final KeyMapping TOGGLE_DODGE = new KeyMapping(
            "key.autoparry.toggle_dodge", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.autoparry");

    private AutoParryKeys() {}

    public static void register() {
        MinecraftForge.EVENT_BUS.register(new Object() {
            @SubscribeEvent
            public void registerKeys(RegisterKeyMappingsEvent event) {
                event.register(TOGGLE_PARRY);
                event.register(TOGGLE_DODGE);
            }
        });
    }
}
