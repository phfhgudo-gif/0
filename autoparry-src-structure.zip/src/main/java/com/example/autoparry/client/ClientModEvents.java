package com.example.autoparry.client;

import com.example.autoparry.AutoParryConfig;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "autoparry", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientModEvents {
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent event) {
        if (event.phase != ClientTickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        while (AutoParryKeys.TOGGLE_PARRY.consumeClick()) {
            AutoParryConfig.autoParryEnabled = !AutoParryConfig.autoParryEnabled;
        }
        while (AutoParryKeys.TOGGLE_DODGE.consumeClick()) {
            AutoParryConfig.autoDodgeEnabled = !AutoParryConfig.autoDodgeEnabled;
        }
    }
}
