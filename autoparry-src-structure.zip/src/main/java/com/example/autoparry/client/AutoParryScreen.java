package com.example.autoparry.client;

import com.example.autoparry.AutoParryConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Optional configuration screen; no automatic chat/status messages are emitted. */
public final class AutoParryScreen extends Screen {
    public AutoParryScreen() {
        super(Component.translatable("screen.autoparry.title"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.drawCenteredString(font, title, width / 2, 30, 0xFFFFFF);
        graphics.drawCenteredString(font,
                Component.translatable("screen.autoparry.parry", AutoParryConfig.autoParryEnabled),
                width / 2, 60, 0xFFFFFF);
        graphics.drawCenteredString(font,
                Component.translatable("screen.autoparry.dodge", AutoParryConfig.autoDodgeEnabled),
                width / 2, 80, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
