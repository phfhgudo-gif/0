package com.example.autoparry.client;

import com.example.autoparry.AutoParryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "autoparry", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AutoDodgeHandler {
    private int cooldown;

    @SubscribeEvent
    public void tick(ClientTickEvent event) {
        if (event.phase != ClientTickEvent.Phase.END || !AutoParryConfig.autoDodgeEnabled) return;
        if (cooldown > 0) { cooldown--; return; }

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null) return;

        LivingEntity threat = ThreatScanner.findNearestThreat();
        if (ThreatScanner.isThreatening(threat)) {
            // Conservative client-side dodge movement: step backward from the threat.
            double dx = player.getX() - threat.getX();
            double dz = player.getZ() - threat.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len > 0.001D) {
                player.setDeltaMovement(player.getDeltaMovement().add(dx / len * 0.18D, 0.02D, dz / len * 0.18D));
            }
            cooldown = AutoParryConfig.actionCooldownTicks * 2;
        }
    }
}
