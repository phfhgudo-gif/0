package com.example.autoparry.client;

import com.example.autoparry.AutoParryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;

public final class ThreatScanner {
    private ThreatScanner() {}

    public static LivingEntity findNearestThreat() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return null;

        return mc.level.getEntitiesOfClass(Mob.class,
                        mc.player.getBoundingBox().inflate(AutoParryConfig.detectionRange),
                        mob -> mob.isAlive() && mob != mc.player)
                .stream()
                .filter(mob -> mob.getTarget() == mc.player || mob.distanceToSqr(mc.player) <= 9.0D)
                .min((a, b) -> Double.compare(a.distanceToSqr(mc.player), b.distanceToSqr(mc.player)))
                .orElse(null);
    }

    public static boolean isThreatening(LivingEntity entity) {
        if (entity == null) return false;
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && entity.isAlive()
                && entity.distanceToSqr(mc.player) <= AutoParryConfig.detectionRange * AutoParryConfig.detectionRange
                && (entity instanceof Mob mob && mob.getTarget() == mc.player);
    }
}
