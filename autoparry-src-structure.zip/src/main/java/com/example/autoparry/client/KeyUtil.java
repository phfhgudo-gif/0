package com.example.autoparry.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;

public final class KeyUtil {
    private KeyUtil() {}

    /** Attempts a normal client-side use action; Epic Fight can consume/replace it when applicable. */
    public static void useMainHand() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.gameMode == null) return;
        player.swing(InteractionHand.MAIN_HAND);
        player.startUsingItem(InteractionHand.MAIN_HAND);
    }
}
