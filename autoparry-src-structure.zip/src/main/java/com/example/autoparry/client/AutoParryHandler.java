package com.example.autoparry.client;

import com.example.autoparry.AutoParryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "autoparry", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AutoParryHandler {
    private int cooldown;

    @SubscribeEvent
    public void tick(ClientTickEvent event) {
        if (event.phase != ClientTickEvent.Phase.END || !AutoParryConfig.autoParryEnabled) return;
        if (cooldown > 0) { cooldown--; return; }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;

        LivingEntity threat = ThreatScanner.findNearestThreat();
        if (ThreatScanner.isThreatening(threat)) {
            KeyUtil.useMainHand();
            cooldown = AutoParryConfig.actionCooldownTicks;
        }
    }
}
