package com.example.autoparry.client;

import net.minecraftforge.common.MinecraftForge;

public final class ClientInit {
    private static boolean registered;

    private ClientInit() {}

    public static void register() {
        if (registered) return;
        registered = true;
        AutoParryKeys.register();
        MinecraftForge.EVENT_BUS.register(new ClientModEvents());
        MinecraftForge.EVENT_BUS.register(new AutoParryHandler());
        MinecraftForge.EVENT_BUS.register(new AutoDodgeHandler());
    }
}
