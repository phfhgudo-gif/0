package com.example.autoparry;

import com.example.autoparry.client.ClientInit;
import net.minecraftforge.fml.common.Mod;

@Mod(AutoParryMod.MOD_ID)
public final class AutoParryMod {
    public static final String MOD_ID = "autoparry";

    public AutoParryMod() {
        ClientInit.register();
    }
}
