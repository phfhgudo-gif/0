package com.example.autoparry.client;

import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.fml.ModLoadingContext;

/** Client-only setup. Only ever called through DistExecutor on the client. */
public final class ClientInit {
    private ClientInit() {}

    /** Makes the "Config" button in the Mods menu open the autoparry on/off screen. */
    public static void register() {
        ModLoadingContext.get().registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class,
                () -> new ConfigScreenHandler.ConfigScreenFactory((mc, parent) -> new AutoParryScreen(parent)));
    }
}
