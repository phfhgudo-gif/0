package com.example.autoparry.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

final class KeyUtil {
    private KeyUtil() {}

    /** True if the player is really holding the physical key/button bound to this mapping. */
    static boolean isPhysicallyDown(Minecraft mc, KeyMapping mapping) {
        long window = mc.getWindow().getWindow();
        InputConstants.Key key = mapping.getKey();
        switch (key.getType()) {
            case MOUSE:
                return GLFW.glfwGetMouseButton(window, key.getValue()) == GLFW.GLFW_PRESS;
            case KEYSYM:
                return InputConstants.isKeyDown(window, key.getValue());
            default:
                return false;
        }
    }
}
