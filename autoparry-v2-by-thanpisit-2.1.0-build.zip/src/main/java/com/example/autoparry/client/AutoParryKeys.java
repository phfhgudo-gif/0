package com.example.autoparry.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

public final class AutoParryKeys {
    public static final String CATEGORY = "key.categories.autoparry";

    // Auto parry: V on, B off
    public static final KeyMapping ENABLE = new KeyMapping("key.autoparry.enable",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);
    public static final KeyMapping DISABLE = new KeyMapping("key.autoparry.disable",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CATEGORY);

    // Auto dodge: "." on, ";" key (":" with Shift) off
    public static final KeyMapping DODGE_ENABLE = new KeyMapping("key.autoparry.dodge_enable",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_PERIOD, CATEGORY);
    public static final KeyMapping DODGE_DISABLE = new KeyMapping("key.autoparry.dodge_disable",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_SEMICOLON, CATEGORY);

    // Opens the on/off menu
    public static final KeyMapping OPEN_MENU = new KeyMapping("key.autoparry.open_menu",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O, CATEGORY);

    private AutoParryKeys() {}
}
